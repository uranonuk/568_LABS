# Do not alter this file

hostname        = 'id.ca1.bioconnectid.com'
username        = 'ece568'
password        = 'XdjXSaPba.3JjCe4'

