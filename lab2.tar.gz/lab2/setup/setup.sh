#!/bin/bash

python3 ./get-pip.py --user --no-warn-script-location
~/.local/bin/pip3 install --user requests qrcode-terminal --no-warn-script-location

